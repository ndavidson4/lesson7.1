function Movie() {
  return (
      <div className="Movie">

          <h2>Movie Title: The Batman</h2>

          <h4>Director: Matt Reeves</h4>
          
          <p>Stars: Robert Pattinson, Zoe Kravitz</p>

      </div>
  );
}

export default Movie;